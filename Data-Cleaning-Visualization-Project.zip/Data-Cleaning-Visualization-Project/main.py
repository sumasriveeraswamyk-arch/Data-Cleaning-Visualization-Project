import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv('dataset/sales_data.csv')

print("Original Dataset:")
print(df)

# Remove duplicates
df = df.drop_duplicates()

# Fill missing values
df['Sales'] = df['Sales'].fillna(df['Sales'].mean())
df['Profit'] = df['Profit'].fillna(df['Profit'].median())

# Outlier Removal using IQR
Q1 = df['Sales'].quantile(0.25)
Q3 = df['Sales'].quantile(0.75)
IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

clean_df = df[(df['Sales'] >= lower) & (df['Sales'] <= upper)]

print("\nCleaned Dataset:")
print(clean_df)

# Create Visualizations

# Sales by Category
plt.figure(figsize=(8,5))
sns.barplot(x='Category', y='Sales', data=clean_df)
plt.title('Sales by Category')
plt.savefig('images/category_distribution.png')
plt.close()

# Profit Distribution
plt.figure(figsize=(8,5))
sns.boxplot(x='Region', y='Profit', data=clean_df)
plt.title('Profit Distribution by Region')
plt.savefig('images/profit_distribution.png')
plt.close()

# Sales Contribution
sales_summary = clean_df.groupby('Category')['Sales'].sum()

plt.figure(figsize=(6,6))
sales_summary.plot(kind='pie', autopct='%1.1f%%')
plt.ylabel('')
plt.title('Sales Contribution by Category')
plt.savefig('images/sales_contribution.png')
plt.close()

print("\nProject Completed Successfully!")
